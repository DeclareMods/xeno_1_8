# Welcome to My Repository

From beginning, I was a huge fan of open-source coding.  I was thinking: if there was place where I can see other people's code, I could very well improve my own practices.  I started making this repository to help beginners with [Roblox Lua](http://developer.roblox.com), so they can help continue Powering Imagination™.

## Before Using It

Don't forget that there are people out there who need scripting  help, so *let's make sure to make their experience an educational one*.
