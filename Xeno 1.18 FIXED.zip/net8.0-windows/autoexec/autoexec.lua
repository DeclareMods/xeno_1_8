local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

-- Create the GUI
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "XenoInjectedGui"
screenGui.ResetOnSpawn = false
screenGui.Parent = game.CoreGui

local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 600, 0, 400)
mainFrame.Position = UDim2.new(0.5, -300, 0.5, -200)
mainFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
mainFrame.BorderSizePixel = 0
mainFrame.Parent = screenGui

local cornerRadius = Instance.new("UICorner")
cornerRadius.CornerRadius = UDim.new(0, 30)
cornerRadius.Parent = mainFrame

local gradient = Instance.new("UIGradient")
gradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(45, 70, 180)),
    ColorSequenceKeypoint.new(0.5, Color3.fromRGB(60, 90, 200)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(75, 110, 220))
})
gradient.Rotation = 45
gradient.Parent = mainFrame

local shine = Instance.new("Frame")
shine.Size = UDim2.new(1, 0, 1, 0)
shine.BackgroundTransparency = 0.8
shine.BorderSizePixel = 0
shine.Parent = mainFrame

local shineGradient = Instance.new("UIGradient")
shineGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)),
    ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 255, 255)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255))
})
shineGradient.Transparency = NumberSequence.new({
    NumberSequenceKeypoint.new(0, 1),
    NumberSequenceKeypoint.new(0.5, 0.8),
    NumberSequenceKeypoint.new(1, 1)
})
shineGradient.Rotation = 45
shineGradient.Parent = shine

local iconImage = Instance.new("ImageLabel")
iconImage.Size = UDim2.new(0, 200, 0, 200)
iconImage.Position = UDim2.new(0.5, -100, 0, 30)
iconImage.BackgroundTransparency = 1
iconImage.Image = "rbxassetid://113271119943813"
iconImage.Parent = mainFrame

local textLabel = Instance.new("TextLabel")
textLabel.Size = UDim2.new(1, 0, 0, 60)
textLabel.Position = UDim2.new(0, 0, 0, 240)
textLabel.BackgroundTransparency = 1
textLabel.Text = "Xeno is injected"
textLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
textLabel.Font = Enum.Font.GothamBold
textLabel.TextSize = 48
textLabel.Parent = mainFrame

local function createButton(text, position)
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(0.4, 0, 0, 60)
    button.Position = position
    button.BackgroundColor3 = Color3.fromRGB(88, 101, 242)
    button.BorderSizePixel = 0
    button.Text = text
    button.TextColor3 = Color3.fromRGB(255, 255, 255)
    button.Font = Enum.Font.GothamSemibold
    button.TextSize = 24
    button.Parent = mainFrame

    local buttonCorner = Instance.new("UICorner")
    buttonCorner.CornerRadius = UDim.new(0, 15)
    buttonCorner.Parent = button

    local buttonGradient = Instance.new("UIGradient")
    buttonGradient.Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0, Color3.fromRGB(108, 121, 255)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(88, 101, 242))
    })
    buttonGradient.Rotation = 90
    buttonGradient.Parent = button

    button.MouseEnter:Connect(function()
        TweenService:Create(button, TweenInfo.new(0.3), {Size = UDim2.new(0.42, 0, 0, 65)}):Play()
    end)

    button.MouseLeave:Connect(function()
        TweenService:Create(button, TweenInfo.new(0.3), {Size = UDim2.new(0.4, 0, 0, 60)}):Play()
    end)

    return button
end

local copyButton = createButton("Copy Invite", UDim2.new(0.05, 0, 1, -80))
local joinButton = createButton("Join Discord", UDim2.new(0.55, 0, 1, -80))

-- Create close button
local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 40, 0, 40)
closeButton.Position = UDim2.new(1, -50, 0, 10)
closeButton.BackgroundColor3 = Color3.fromRGB(255, 100, 100)
closeButton.BorderSizePixel = 0
closeButton.Text = "X"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.Font = Enum.Font.GothamBold
closeButton.TextSize = 24
closeButton.Parent = mainFrame

local closeButtonCorner = Instance.new("UICorner")
closeButtonCorner.CornerRadius = UDim.new(0, 10)
closeButtonCorner.Parent = closeButton

-- Make the frame draggable
local dragging
local dragInput
local dragStart
local startPos

local function update(input)
    local delta = input.Position - dragStart
    mainFrame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
end

mainFrame.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPos = mainFrame.Position

        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
            end
        end)
    end
end)

mainFrame.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
        dragInput = input
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if input == dragInput and dragging then
        update(input)
    end
end)

-- Function to handle Discord invite
local function handleDiscordInvite()
    local inviteLink = "https://discord.gg/gjxb4dz6aJ"
    setclipboard(inviteLink)
    game:GetService("StarterGui"):SetCore("SendNotification", {
        Title = "Discord Invite",
        Text = "Invite link copied to clipboard!",
        Duration = 5
    })
end

-- Function to attempt joining Discord
local function joinDiscord()
    local inviteLink = "https://discord.gg/gjxb4dz6aJ"
    setclipboard(inviteLink)
    game:GetService("StarterGui"):SetCore("SendNotification", {
        Title = "Join Discord",
        Text = "Invite link copied. Please open Discord manually to join.",
        Duration = 5
    })
end

copyButton.MouseButton1Click:Connect(handleDiscordInvite)
joinButton.MouseButton1Click:Connect(joinDiscord)

-- Fade in function
local function fadeIn()
    mainFrame.BackgroundTransparency = 1
    iconImage.ImageTransparency = 1
    textLabel.TextTransparency = 1
    copyButton.BackgroundTransparency = 1
    copyButton.TextTransparency = 1
    joinButton.BackgroundTransparency = 1
    joinButton.TextTransparency = 1
    closeButton.BackgroundTransparency = 1
    closeButton.TextTransparency = 1
    shine.BackgroundTransparency = 1

    local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    
    TweenService:Create(mainFrame, tweenInfo, {BackgroundTransparency = 0}):Play()
    TweenService:Create(iconImage, tweenInfo, {ImageTransparency = 0}):Play()
    TweenService:Create(textLabel, tweenInfo, {TextTransparency = 0}):Play()
    TweenService:Create(copyButton, tweenInfo, {BackgroundTransparency = 0, TextTransparency = 0}):Play()
    TweenService:Create(joinButton, tweenInfo, {BackgroundTransparency = 0, TextTransparency = 0}):Play()
    TweenService:Create(closeButton, tweenInfo, {BackgroundTransparency = 0, TextTransparency = 0}):Play()
    TweenService:Create(shine, tweenInfo, {BackgroundTransparency = 0.8}):Play()
end

-- Fade out function
local function fadeOut()
    local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    
    TweenService:Create(mainFrame, tweenInfo, {BackgroundTransparency = 1}):Play()
    TweenService:Create(iconImage, tweenInfo, {ImageTransparency = 1}):Play()
    TweenService:Create(textLabel, tweenInfo, {TextTransparency = 1}):Play()
    TweenService:Create(copyButton, tweenInfo, {BackgroundTransparency = 1, TextTransparency = 1}):Play()
    TweenService:Create(joinButton, tweenInfo, {BackgroundTransparency = 1, TextTransparency = 1}):Play()
    TweenService:Create(closeButton, tweenInfo, {BackgroundTransparency = 1, TextTransparency = 1}):Play()
    TweenService:Create(shine, tweenInfo, {BackgroundTransparency = 1}):Play()
    
    wait(0.5)  -- Wait for the fade out to complete
    screenGui:Destroy()
end

closeButton.MouseButton1Click:Connect(fadeOut)

-- Start with fade in
fadeIn()